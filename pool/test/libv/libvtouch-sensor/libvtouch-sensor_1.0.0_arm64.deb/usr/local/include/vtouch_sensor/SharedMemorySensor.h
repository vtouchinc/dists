#pragma once
#include "VTSensorDefine.h"
#include "VTSensor.h"

VTSENSOR_NAMESPACE_OPEN

class SharedMemorySensor final : public VTSensor 
{    
public:
    SharedMemorySensor();
    ~SharedMemorySensor();

    bool InitializeLiveMode() override;
    bool InitializeFileMode() override;
    void Release() override;

    void UpdateFrameFromCamera() override;
    void UpdateFrameFromFile() override;

    float GetCameraF() override;
};

VTSENSOR_NAMESPACE_CLOSE