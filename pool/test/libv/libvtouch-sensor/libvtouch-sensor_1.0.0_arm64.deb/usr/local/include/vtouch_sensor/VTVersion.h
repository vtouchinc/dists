#pragma once
#include "VTSensorDefine.h"

#include <string>

VTSENSOR_NAMESPACE_OPEN

extern const std::string g_gitVersion;

VTSENSOR_NAMESPACE_CLOSE