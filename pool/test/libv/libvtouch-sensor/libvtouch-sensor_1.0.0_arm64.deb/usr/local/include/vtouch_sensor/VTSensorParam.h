/**************************************************************
/* @file VTSensorParam.h
/* @author Sangjoon Hong (sangjoon.hong@vtouch.io)
/* @brief 
/* @date 2018-11-19
/* 
/* @copyright Copyright (c) 2018. VTouch all right reserved.
/* 
**************************************************************/
#pragma once
#include "VTSensorDefine.h"

VTSENSOR_NAMESPACE_OPEN

class DistortionParam
{
public:
	double K1;  //Distortion K1
	double K2;  //Distortion K2
	double K3;  //Distortion K3
	double P1;  //Distortion P1
	double P2;  //Distortion P2
	double Skew;

	DistortionParam()
	{
		K1 = 0;
		K2 = 0;
		K3 = 0;
		P1 = 0;
		P2 = 0;
		Skew = 0;
	};
};

class IntrinsicParam
{
public:
	double Fx;	//Intrinsic Fx
	double Fy;	//Intrinsic Fy
	double Cx;	//Intrinsic Cx
    double Cy;	//Intrinsic Cy

	IntrinsicParam()
	{
		Fx = 0;
		Fy = 0;
		Cx = 0;
		Cy = 0;
	};
};

VTSENSOR_NAMESPACE_CLOSE