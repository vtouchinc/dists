/*
 * CubeEyeLens.h
 *
 *  Created on: 2020. 12. 17.
 *      Author: erato
 */

#ifndef CUBEEYELENS_H_
#define CUBEEYELENS_H_

#include "CubeEye.h"

BEGIN_NAMESPACE

//typedef struct _decl_dll CubeEyeLens
//{
//
//} CubeEyeLens;

class _decl_dll CubeEyeLens
{
public:

public:
	struct IntrinsicParameters {
		struct ForcalLength {
			flt32 fx;
			flt32 fy;
		} forcal;

		struct PrincipalPoint {
			flt32 cx;
			flt32 cy;
		} principal;
	};

	struct DistortionCoefficients {
		struct RadialCoefficient {
			flt64 k1;
			flt64 k2;
			flt64 k3;
		} radial;

		struct TangentialCoefficient {
			flt64 p1;
			flt64 p2;
		} tangential;

		flt64 skewCoefficient;
	};

	struct ExtrinsicParameters {
		struct RotationParameters {
			flt32 r1[3];
			flt32 r2[3];
			flt32 r3[3];
		} rotation;

		struct TranslationParameters {
			flt32 tx;
			flt32 ty;
			flt32 tz;
		} translation;
	};

protected:
	CubeEyeLens() = default;
	virtual ~CubeEyeLens() = default;
};

END_NAMESPACE

#endif /* CUBEEYELENS_H_ */
