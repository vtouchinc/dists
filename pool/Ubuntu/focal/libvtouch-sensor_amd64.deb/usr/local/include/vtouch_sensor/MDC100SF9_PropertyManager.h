#pragma once

#include "VTSensorDefine.h"

#include <string>

VTSENSOR_NAMESPACE_OPEN

class MDC100SF9_PropertyManager
{
public:
    enum PROPERTIES
    {
        LOG_LEVEL,                      // 32 int
        TEMPERATURE,                    // 32 float
        TEMPERATURE_DRV,                // 32 float
        RESET_PROPERTIES,               //    bool
        FRAMERATE,                      //  8 int (1~30 / 7, 15, 30 only)
        ILLUMINATION,                   //    bool
        AUTO_EXPOSURE,                  //    bool
        AMPLITUDE_THRESHOLD_MIN,        // 16 int (0~65535)
        AMPLITUDE_THRESHOLD_MAX,        // 16 int (0~65535)
        DEPTH_RANGE_MAX,                // 16 int (0~4095)
        DEPTH_RANGE_MIN,                // 16 int (0~4095)
        DEPTH_OFFSET,                   // 16 int (-4095~4095)
        SCATTERING_THRESHOLD,           // 16 int (0~4095)
        FLYING_FIXEL_REMOVE_THRESHOLD,  // 16 int (0~4095)                  
        FLYING_FIXEL_REMOVE_FILTER,     //    bool
        NOISE_FILTER_1,                 //    bool
        NOISE_FILTER_2,                 //    bool
        NOISE_FILTER_3,                 //    bool
        MOTION_BLUR_THRESHOLD_1,        //  8 int (0~254)
        MOTION_BLUR_THRESHOLD_2,        //  8 int (0~255)
        MOTION_BLUR_FREQUENCY,          //  8 int (0, 1, 2)
        ROI_SCATTERING_FILTER,          // Multi-parameter (enable, x, y, width, hight, threshold)
        INTEGRATION_TIME,               //  8 INT (0 ~ 67)
        DEPTH_ERROR_REMOVE_THRESHOLD    //  8 int (0~255), Defualt: 255
    };    
    
    enum LOG_LEVEL_SETTINGS
    {
        VERBOSE = 0,
        INFO    = 1,
        DEBUG   = 2,
        WARNING = 3,
        ERROR   = 4
    };

    enum FRAMERATE_SETTINGS
    {
        FPS_7 = 7,
        FPS_15 = 15,
        FPS_30 = 30
    };

    enum MOTION_BLUR_FREQUENCY_SETTINGS
    {
        NOT_USE = 0,
        FREQ_1 = 1,
        DEFAULT = 2 // FREQ_2
    };

private:
    MDC100SF9_PropertyManager();
    static MDC100SF9_PropertyManager *m_instance;

public:
    static MDC100SF9_PropertyManager *GetInstance();
    static void Release();

    static std::string GetString(PROPERTIES properties);

    bool ResetProperty();

    bool SetProperty(PROPERTIES key, bool value);
    bool SetProperty(PROPERTIES key, int value);
    bool SetProperty(PROPERTIES key, float value);

    bool SetProperty(std::string key, bool value);
    bool SetProperty(std::string key, int value);
    bool SetProperty(std::string key, float value);
    
    bool SetProperty(LOG_LEVEL_SETTINGS value);
    bool SetProperty(FRAMERATE_SETTINGS value);
    bool SetProperty(MOTION_BLUR_FREQUENCY_SETTINGS value);
    
    bool SetRoiScatteringFilter(bool enable, int x = 0, int y = 0, int width = 0, int height = 0, int threshold = 0);

    void SetPropertiesFromYML();

    bool PrintProperty(PROPERTIES key);
};

VTSENSOR_NAMESPACE_CLOSE