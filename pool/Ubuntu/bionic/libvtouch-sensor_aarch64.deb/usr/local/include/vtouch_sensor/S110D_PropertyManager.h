#pragma once

#include "VTSensorDefine.h"
#include <map>
#include <string>
#include "VTSensorParam.h"

#define DEVICE_NAME "/dev/v4l-subdev2"

VTSENSOR_NAMESPACE_OPEN

class S110D_PropertyManager
{
// AMPLITUDE_THRESHOLD_MIN,        // 16 int (0~65535)             = 10
// DEPTH_RANGE_MAX,                // 16 int (0~4095)              = 1600
// DEPTH_RANGE_MIN,                // 16 int (0~4095)              = 0
// SCATTERING_THRESHOLD,           // 16 int (0~4095)              = 900
// FLYING_FIXEL_REMOVE_THRESHOLD,  // 16 int (0~4095)              = 200
// MOTION_BLUR_THRESHOLD_1,        //  8 int (0~254)               = 2
// MOTION_BLUR_THRESHOLD_2,        //  8 int (0~255)               = 20
// INTEGRATION_TIME,               //  8 INT (0 ~ 67)              = 61
// DEPTH_ERROR_REMOVE_THRESHOLD    //  8 int (0~255), Defualt: 255 = 60


private:
    int m_fileDescriptor;
    std::map<std::string, int> m_properties;        

    bool m_isSetIntegrationTime;
    
    bool isIntrinsicParamsLoaded;
    IntrinsicParam m_intrinsicParams;
    bool isDistortionParamsLoaded;
    DistortionParam m_distortionParams;

public:
    S110D_PropertyManager();

    void LoadSensorSettings();
    void ApplySettings();

    bool IsSetIntegrationTime();

    IntrinsicParam GetIntrinsics(); 
    DistortionParam GetDistortions();
private:    
    void OpenDevice();
    void CloseDevice();

    void SetControl(char *controlName, char *value);
    void SetRegister(char address, unsigned char *value);
    void GetControl(char *controlName);

    void GetAutoExposure();
    void SetIntegrationTime(unsigned short value);

};

VTSENSOR_NAMESPACE_CLOSE