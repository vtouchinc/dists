#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

int sha3_hash(uint8_t *output, int outLen, uint8_t *input, int inLen, int bitSize, int useSHAKE);