#pragma once

#define VTSENSOR_NAMESPACE_OPEN namespace VTSensor {
#define VTSENSOR_NAMESPACE_CLOSE }

#define FPS 30

VTSENSOR_NAMESPACE_OPEN

enum SENSOR
{
    // Warning !!
    // 리스트의 변경이 있어도 이미 부여된 숫자는 바꾸지 말것!
    // Core 에서 숫자로 호출하기 때문에 햇갈릴 수 있음.
    MEREE_MDC100SF9 = 0,
    VTOUCH_VTDPLAYER = 1,
    VTOUCH_SHARED_MEMORY
};

VTSENSOR_NAMESPACE_CLOSE