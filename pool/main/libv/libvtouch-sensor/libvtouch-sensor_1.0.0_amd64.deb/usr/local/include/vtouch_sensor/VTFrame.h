/**************************************************************
/* @brief 
/* @author SANGJOON HONG
/* 
/* @file VTFrame.h
/* @author SANGJOON HONG
/* @date 2018-08-27
**************************************************************/
#pragma once
#include "VTSensorDefine.h"

#include <opencv2/core.hpp>

VTSENSOR_NAMESPACE_OPEN

class VTFrame
{
protected:
    int m_width;
    int m_height;

    cv::Mat *m_worldX; // x
    cv::Mat *m_worldY; // y
    cv::Mat *m_worldZ; // z
    cv::Mat *m_pointcloud; // 3 Channel

    cv::Mat *m_depthImage;
    cv::Mat *m_infraRedImage;

public:
    VTFrame();
    VTFrame(VTFrame *vtFrame);
    VTFrame(cv::Mat *x, cv::Mat *y, cv::Mat *z, cv::Mat *ir);

    // For MDC200SP
    VTFrame(int width, int height, float *xyzIrData);

    // For EVK75123
    VTFrame(int width, int height, unsigned short *distanceData, unsigned short *infraRedData);
    VTFrame(int width, int height, short *xData, short *yData, short *zData, unsigned short *infraRedData);

    // For VTDPLAYER
    VTFrame(int width, int height, float *xyzData, unsigned short *irData);

    virtual ~VTFrame();

    //cv::Mat *GetDistanceImage();
    cv::Mat *GetWorldX();
    cv::Mat *GetWorldY();
    cv::Mat *GetWorldZ();
    cv::Mat *GetPointcloud();
    cv::Mat *GetDepthImage();
    cv::Mat *GetInfraRedImage();

    int GetWidth();
    int GetHeight();

    bool GetWorldPositionAt(const int x, const int y, cv::Point3f &worldPosition);
};

VTSENSOR_NAMESPACE_CLOSE