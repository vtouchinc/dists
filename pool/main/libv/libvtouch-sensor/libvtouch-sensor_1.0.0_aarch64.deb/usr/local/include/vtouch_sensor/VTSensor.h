/**************************************************************
/* @brief Sensor Base Class
/* @author SANGJOON HONG
/* 
/* @file VTSensor.h
/* @author SANGJOON HONG
/* @date 2018-08-22
**************************************************************/
#pragma once
#include "VTSensorDefine.h"
#include "VTFrame.h"
#include "VTSensorParam.h"
#include "SharedMemoryManager.h"

#include <fstream>
#include <string>
#include <thread>
#include <queue>
#include <functional>

VTSENSOR_NAMESPACE_OPEN

enum SENSOR_MODE
{
    LIVE_MODE = 0,
    FILE_MODE
};    

class VTSensor
{    
protected:
    SENSOR_MODE m_sensorMode;
    std::string m_filePath;
    bool m_isFileEnd;

    // Sensor Parameters
    IntrinsicParam m_intrinsicParams;
    DistortionParam m_distortionParams;

    // Frame
    int m_frameWidth;
    int m_frameHeight;
    std::queue<VTFrame *> m_frameBuffer;
    std::function<void()> m_updateFrameFunction;

    // For Shared Memory
    SharedMemoryManager *m_sharedMemeoryManager;

    // For File Read
    int m_frameCount;
    std::ifstream m_inputFileStream;

    // Thread
    std::thread *m_updateFrameThread;
    bool m_isUpdateOn;

    // Error
    std::string m_lastError;

    VTSensor();
public:
    virtual ~VTSensor();
    
    static VTSensor* GetVTSensor(SENSOR sensorType, SENSOR_MODE sensorMode = LIVE_MODE, std::string filePath = "");

    // For Initialize
    bool Initialize();
    virtual bool InitializeLiveMode() = 0;
    virtual bool InitializeFileMode() = 0;
    
    virtual void Release() = 0;
    
    // For Update Frame
    void UpdateFrame();
    virtual void UpdateFrameFromCamera() = 0;
    virtual void UpdateFrameFromFile() = 0;
    bool IsFileEnd();

    // For Thread
    bool StartUpdateFrameThread();
    bool StopUpdateFrameThread();

    // Frame Getter & Setter
    VTFrame *GetFrame();
    void SetFrame(VTFrame *frame);  

    // Width & Height Getter
    int GetFrameWidth();
    int GetFrameHeight();

    // Intrinsics & Distortion Getters
    virtual float GetCameraF() = 0;    
    void GetIntrinsics(float &fX, float &fY, float &cX, float &cY);    
    IntrinsicParam GetIntrinsics();
    DistortionParam GetDistortions();
            
    std::string GetLastError();
    void PrintGitVersion();

    // Camera Interface
    //virtual void SetAutoExposure(bool flag = true) = 0;
};

VTSENSOR_NAMESPACE_CLOSE