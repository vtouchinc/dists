#pragma once 

#include "VTSensorDefine.h"
#include "VTSensor.h"

#include "S110D_PropertyManager.h"

#include <string>
#include <opencv2/opencv.hpp>

#define NUM_PLANES 1

VTSENSOR_NAMESPACE_OPEN


const int FRAME_WIDTH = 640;
const int FRAME_HEIGHT = 480;


typedef struct PCL {
	short x;
	short y;
	short z;
	short a;
} PCL;

using PCL_FRAME = std::array<PCL, FRAME_WIDTH * FRAME_HEIGHT>;

class S110D final : public VTSensor 
{    
private:    
    PCL_FRAME _pcl_frame;

    enum vb2_memory 
    {
        VB2_MEMORY_UNKNOWN      = 0,
        VB2_MEMORY_MMAP         = 1,
    };

    struct buffer 
    {
        void   *start[NUM_PLANES];
        size_t  length[NUM_PLANES];
    };

    const std::string DEVICE_PATH = "/dev/video0";

    //cv::Mat m_depth;
    //cv::Mat m_infra;
    short *xData;
    short *yData;
    short *zData;
    unsigned short *infraRedData;

    S110D_PropertyManager m_propertyManager;

    int m_cameraFileDescriptor;

    struct buffer *m_buffers;
    unsigned int n_buffers;

    void InitDevice(void);
    void InitMemoryMap(void);

    void StopCapturing(void);
    void StartCapturing(void);
    
    int ReadFrame(void);

    void Parse(void *_data);

    int xioctl(int fh, int request, void *arg);

public:
    S110D();
    ~S110D();

    bool InitializeLiveMode() override;
    bool InitializeFileMode() override;
    void Release() override;

    void UpdateFrameFromCamera() override;
    void UpdateFrameFromFile() override;

    float GetCameraF() override;
};

VTSENSOR_NAMESPACE_CLOSE