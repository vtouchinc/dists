#pragma once
#include <string>

#define MARKER_FILE_NAME "./VTouch.mkr"

#define HASH_OUT_SIZE 512
#define MARKER_VER 1

class VTouchMarker
{
private:
    std::string m_markerFileName;
    std::string m_lshwString;

    // For MarkerFile
    unsigned int m_markerVersion;
    std::string m_hashString;

public:
    VTouchMarker();
    ~VTouchMarker();

    bool RunVTouchMarker();
    void GenerateMarkerFile();

private:
    void Run_lshw();
    std::string HashBySHA3(std::string message);
    
    bool CheckMarkerFile();

    void ReadMarker();
    void WriteMarker();

    std::string GetProductName();
    std::string GetProductSerial();
};