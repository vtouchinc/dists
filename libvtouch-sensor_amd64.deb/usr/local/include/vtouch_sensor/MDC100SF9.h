/**************************************************************
/* @brief MEREE Camera MDC200SP Class
/* @author SANGJOON HONG
/* 
/* @file MDC200SP.h
/* @author SANGJOON HONG
/* @date 2018-08-22
**************************************************************/
#pragma once
#include "VTSensorDefine.h"
#include "VTSensor.h"

#include <map>

#include <CubeEyeSink.h>
#include <CubeEyeCamera.h>
#include <CubeEyeBasicFrame.h>
#include <CubeEyePointCloudFrame.h>
#include <CubeEyeIntensityPointCloudFrame.h>

VTSENSOR_NAMESPACE_OPEN

class MDC100SF9 final : public VTSensor,
                        public meere::sensor::CubeEyeSink,
                        public meere::sensor::CubeEyeCamera::PreparedListener
{
private:
    meere::sensor::sptr_camera m_camera;
    //std::map<std::string, meere::sensor::sptr_property> m_properties;
    
public:
    MDC100SF9(SENSOR_MODE sensorMode = SENSOR_MODE::LIVE_MODE, std::string filePath = "");
    ~MDC100SF9();

    bool InitializeLiveMode() override;
    bool InitializeFileMode() override;
    void Release() override;

    void UpdateFrameFromCamera() override;
    void UpdateFrameFromFile() override;

    float GetCameraF() override;
    
    // void GetCameraDefaultParameters();
    // bool SetPropertiesFromYML();
    // void SaveProperties();
    // void PrintProperty(const meere::sensor::sptr_property& prop);

    virtual std::string name() const;
	virtual void onCubeEyeCameraState(const meere::sensor::ptr_source source, meere::sensor::State state);
	virtual void onCubeEyeCameraError(const meere::sensor::ptr_source source, meere::sensor::Error error);
	virtual void onCubeEyeFrameList(const meere::sensor::ptr_source source , const meere::sensor::sptr_frame_list& frames);
    virtual void onCubeEyeCameraPrepared(const meere::sensor::ptr_camera camera);

    //void SetAutoExposure(bool flag = true);
    void PrintSDKVersion();
    void PrintCameraFirmwareVersion();
};

VTSENSOR_NAMESPACE_CLOSE