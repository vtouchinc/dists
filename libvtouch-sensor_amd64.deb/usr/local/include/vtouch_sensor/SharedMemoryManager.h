#pragma once
#include "VTSensorDefine.h"
#include "VTFrame.h"

#define SHARED_MEMORY_KEY 0xFFFF0419
#define SEMAPHORE_KEY 0xFFFF0419

VTSENSOR_NAMESPACE_OPEN

class SharedMemoryManager
{
public:
    enum MODE
    {
        READ,
        WRITE
    };
private:
    static SharedMemoryManager *m_instance;

    const key_t m_sharedMemoryKey;
    int m_sharedMemoryId;
    void *m_memorySegment;

    const key_t m_semaphoreKey;
    int m_semaphoreId;

    MODE m_mode;

    SharedMemoryManager();    
public:
    static SharedMemoryManager *GetInstance();
    static void Destroy();

    void Initialize(unsigned int memorySize);
    void Release();

    void WriteFrame(VTFrame *frame);
    VTFrame *ReadFrame(int width, int height);

    void SetMode(MODE mode);
    MODE GetCurrentMode();

private:
    void SemaphoreLock();
    void SemaphoreUnlock();
};

VTSENSOR_NAMESPACE_CLOSE