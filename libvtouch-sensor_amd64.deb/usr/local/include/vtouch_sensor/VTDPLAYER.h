/**************************************************************
/* @file VTDPLAYER.h
/* @brief 
/* 
/* @author Sangjoon Hong
/* @date 2018-12-13
/* 
/* @copyright Copyright (c) 2018. VTouch all right reserved.
**************************************************************/
#pragma once
#include "VTSensorDefine.h"
#include "VTSensor.h"

VTSENSOR_NAMESPACE_OPEN

class VTDPLAYER final : public VTSensor 
{    
public:
    VTDPLAYER(std::string filePath);
    ~VTDPLAYER();

    bool InitializeLiveMode() override;
    bool InitializeFileMode() override;
    void Release() override;

    void UpdateFrameFromCamera() override;
    void UpdateFrameFromFile() override;

    float GetCameraF() override;

    void SetAutoExposure(bool flag = true);
};

VTSENSOR_NAMESPACE_CLOSE