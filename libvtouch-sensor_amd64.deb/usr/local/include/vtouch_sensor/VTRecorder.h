/**************************************************************
/* @file VTRecorder.h
/* @brief 
/* 
/* @author Sangjoon Hong
/* @date 2018-12-13
/* 
/* @copyright Copyright (c) 2018. VTouch all right reserved.
**************************************************************/
#pragma once
#include "VTSensorDefine.h"
#include "VTSensorParam.h"
#include "VTFrame.h"
#include "VTSensor.h"

#include <queue>
#include <fstream>
#include <thread>

VTSENSOR_NAMESPACE_OPEN

class VTRecorder
{
private:
    int m_width;
    int m_height;
    int m_frameCount;
    
    IntrinsicParam m_intrinsics;
    DistortionParam m_distortions;

    SENSOR m_sensorType;

    std::queue<VTFrame *> m_frameBuffer;

    std::string m_fileName;
    std::ofstream m_outputFileStream;

    // Thread
    std::thread *m_writeFrameThread;
    bool m_isRecordingOn;

public:
    VTRecorder();
    ~VTRecorder();

    bool Initialize(VTSensor *sensor, SENSOR sensorType);
    void Release();

    void SetFrame(VTFrame *frame);
    
    void StartRecording();
    void StopRecording();

    bool IsRecording();

    void Test();

private:
    void MakeFile();
    void WriteHeader();
    void WriteFrameCount();
    void WriteFrame();
};

VTSENSOR_NAMESPACE_CLOSE